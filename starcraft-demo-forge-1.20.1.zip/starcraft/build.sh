#!/usr/bin/env bash
# ============================================================
#  星辉工艺 — 一键构建脚本 (Linux / macOS)
#  生成自 BlockForge Studio
# ============================================================
set -e
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "[错误] 没有找到 Java。请先安装 JDK 17：https://adoptium.net/"
  exit 1
fi

echo "[1/2] 正在构建模组 (./gradlew build) ..."
echo "      首次运行会下载 Gradle 与 Forge 依赖，请耐心等待。"
chmod +x ./gradlew 2>/dev/null || true
./gradlew build "$@"

echo "[2/2] 构建完成！产物位于 build/libs/"
ls -lh build/libs/*.jar 2>/dev/null || true
echo "把 jar 复制到 ~/.minecraft/mods/ 即可安装。"
