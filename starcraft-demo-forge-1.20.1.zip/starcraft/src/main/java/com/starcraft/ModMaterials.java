package com.starcraft;

import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.server.level.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.energy.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;
import net.minecraft.world.food.*;
import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.chat.*;
import net.minecraft.nbt.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.*;
import net.minecraft.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.*;
import java.util.function.Supplier;
import com.starcraft.StarcraftMod;
import com.starcraft.ModMaterials;
import com.starcraft.registry.*;
import com.starcraft.item.*;
import com.starcraft.block.*;
import com.starcraft.block.entity.*;
import com.starcraft.menu.*;
import com.starcraft.client.screen.*;
import com.starcraft.entity.*;
import com.starcraft.entity.model.*;
import com.starcraft.client.*;
import com.starcraft.energy.ModEnergy;

public final class ModMaterials {
    public static void init() { /* 触发静态初始化，保证材料在物品注册前就绪 */ }

    public static final Tier STAR_PICKAXE_TIER = new SimpleTier(
        1200, 10.0f, 2.0f, 3, 15, "incorrect_for_diamond_tool",
        () -> Ingredient.of(ModItems.STAR_INGOT.get()));
    public static final Tier THUNDER_BLADE_TIER = new SimpleTier(
        1600, 8.0f, 8.0f, 0, 15, "incorrect_for_diamond_tool",
        () -> Ingredient.of(ModItems.STAR_INGOT.get()));
    public static final ArmorMaterial STAR_HELMET_ARMOR = new SimpleArmor(
        "starcraft:star_helmet", 38, 4, 15, 2.0f, 0.1f,
        () -> Ingredient.of(ModItems.STAR_INGOT.get()));

    public static class SimpleTier implements Tier {
        private final int uses, level, enchant;
        private final float speed, damage;
        private final Supplier<Ingredient> repair;
        private final String incorrect;
        public SimpleTier(int uses, float speed, float damage, int level, int enchant, String incorrect, Supplier<Ingredient> repair) {
            this.uses = uses; this.speed = speed; this.damage = damage;
            this.level = level; this.enchant = enchant; this.incorrect = incorrect; this.repair = repair;
        }
        @Override public int getUses() { return uses; }
        @Override public float getSpeed() { return speed; }
        @Override public float getAttackDamageBonus() { return damage; }
        @Deprecated public int getLevel() { return level; }
        @Override public int getEnchantmentValue() { return enchant; }
        @Override public Ingredient getRepairIngredient() { return repair.get(); }
        public TagKey<Block> getIncorrectBlocksForDrops() {
            return TagKey.create(Registries.BLOCK, new ResourceLocation("minecraft", incorrect));
        }
    }

    public static class SimpleArmor implements ArmorMaterial {
        private final String name;
        private final int factor, defense, enchant;
        private final float toughness, knockback;
        private final Supplier<Ingredient> repair;
        public SimpleArmor(String name, int factor, int defense, int enchant, float toughness, float knockback, Supplier<Ingredient> repair) {
            this.name = name; this.factor = factor; this.defense = defense; this.enchant = enchant;
            this.toughness = toughness; this.knockback = knockback; this.repair = repair;
        }
        @Override public int getDurabilityForType(ArmorItem.Type type) {
            int[] mult = {11, 16, 15, 13};
            return mult[type.ordinal()] * factor;
        }
        @Override public int getDefenseForType(ArmorItem.Type type) { return defense; }
        @Override public int getEnchantmentValue() { return enchant; }
        @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_IRON; }
        @Override public Ingredient getRepairIngredient() { return repair.get(); }
        @Override public String getName() { return name; }
        @Override public float getToughness() { return toughness; }
        @Override public float getKnockbackResistance() { return knockback; }
    }

    private ModMaterials() {}
}
