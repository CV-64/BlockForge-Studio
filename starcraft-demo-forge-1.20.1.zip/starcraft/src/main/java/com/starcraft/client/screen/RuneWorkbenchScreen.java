package com.starcraft.client.screen;

import com.starcraft.menu.RuneWorkbenchMenu;
import com.starcraft.StarcraftMod;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.server.level.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.energy.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;
import net.minecraft.world.food.*;
import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.chat.*;
import net.minecraft.nbt.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.*;
import net.minecraft.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.*;
import java.util.function.Supplier;
import com.starcraft.StarcraftMod;
import com.starcraft.ModMaterials;
import com.starcraft.registry.*;
import com.starcraft.item.*;
import com.starcraft.block.*;
import com.starcraft.block.entity.*;
import com.starcraft.menu.*;
import com.starcraft.client.screen.*;
import com.starcraft.entity.*;
import com.starcraft.entity.model.*;
import com.starcraft.client.*;
import com.starcraft.energy.ModEnergy;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import com.mojang.blaze3d.systems.RenderSystem;

public class RuneWorkbenchScreen extends AbstractContainerScreen<RuneWorkbenchMenu> {

    private static final ResourceLocation TEXTURE = new ResourceLocation(StarcraftMod.MODID, "textures/gui/rune_workbench.png");

    public RuneWorkbenchScreen(RuneWorkbenchMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
    }

    @Override protected void renderBg(GuiGraphics gui, float partial, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.setShaderTexture(0, TEXTURE);
        gui.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        int p = menu.getScaledProgress();
        if (p > 0) gui.blit(TEXTURE, leftPos + 78, topPos + 34, 176, 0, p, 16);
        if (menu.getEnergyCapacity() > 0) {
            gui.fill(leftPos + 8, topPos + 76, leftPos + 62, topPos + 81, 0xFF202020);
            gui.fill(leftPos + 8, topPos + 76, leftPos + 8 + menu.getEnergyScaled(), topPos + 81, 0xFF4FC9C0);
        }
    }

    @Override public void render(GuiGraphics gui, int mouseX, int mouseY, float partial) {
        renderBackground(gui);
        super.render(gui, mouseX, mouseY, partial);
        renderTooltip(gui, mouseX, mouseY);
        if (menu.getEnergyCapacity() > 0 && mouseX >= leftPos + 8 && mouseX <= leftPos + 62 &&
            mouseY >= topPos + 74 && mouseY <= topPos + 82) {
            gui.renderTooltip(font, Component.literal(menu.getEnergyStored() + " / " + menu.getEnergyCapacity() + " FE"), mouseX, mouseY);
        }
    }

    @Override protected void renderLabels(GuiGraphics gui, int mouseX, int mouseY) {
        gui.drawString(font, title, 8, 6, 0x404040, false);
        gui.drawString(font, playerInventoryTitle, 8, imageHeight - 94, 0x404040, false);
    }
}
