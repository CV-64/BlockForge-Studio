package com.starcraft.item;

import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.server.level.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.energy.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;
import net.minecraft.world.food.*;
import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.chat.*;
import net.minecraft.nbt.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.*;
import net.minecraft.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.*;
import java.util.function.Supplier;
import com.starcraft.StarcraftMod;
import com.starcraft.ModMaterials;
import com.starcraft.registry.*;
import com.starcraft.item.*;
import com.starcraft.block.*;
import com.starcraft.block.entity.*;
import com.starcraft.menu.*;
import com.starcraft.client.screen.*;
import com.starcraft.entity.*;
import com.starcraft.entity.model.*;
import com.starcraft.client.*;
import com.starcraft.energy.ModEnergy;

public class StarPickaxeItem extends PickaxeItem {

    public StarPickaxeItem() {
        super(ModMaterials.STAR_PICKAXE_TIER, 2, -2.4f, new Properties().stacksTo(1).durability(1200));
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.starcraft.star_pickaxe").withStyle(ChatFormatting.GRAY));
        super.appendHoverText(stack, level, tooltip, flag);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!target.level().isClientSide) {
            target.setSecondsOnFire(5);
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    private static boolean isFastBlock(BlockState state) {
        return state.is(TagKey.create(Registries.BLOCK, new ResourceLocation("minecraft", "mineable_with_pickaxe")))
            || state.is(TagKey.create(Registries.BLOCK, new ResourceLocation("minecraft", "stone")))
            || state.is(TagKey.create(Registries.BLOCK, new ResourceLocation("minecraft", "deepslate")));
    }

    @Override
    public float getDestroySpeed(ItemStack stack, BlockState state) {
        if (isFastBlock(state)) return 16.0f;
        return super.getDestroySpeed(stack, state);
    }

    @Override
    public boolean canPerformAction(ItemStack stack, ToolAction action) {
        return action == ToolActions.PICKAXE_DIG
            || super.canPerformAction(stack, action);
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
        if (slot == EquipmentSlot.MAINHAND) {
            return ImmutableMultimap.<Attribute, AttributeModifier>builder()
                .put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Tool modifier", 2.0f, AttributeModifier.Operation.ADDITION))
                .put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Tool modifier", -2.4f, AttributeModifier.Operation.ADDITION))
                .build();
        }
        return super.getAttributeModifiers(slot, stack);
    }

    @Override
    public boolean isValidRepairItem(ItemStack toRepair, ItemStack repairStack) {
        return repairStack.is(ModItems.STAR_INGOT.get()) || super.isValidRepairItem(toRepair, repairStack);
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return true;
    }
}
