package com.starcraft.entity.model;

import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.server.level.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.energy.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;
import net.minecraft.world.food.*;
import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.chat.*;
import net.minecraft.nbt.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.*;
import net.minecraft.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.*;
import java.util.function.Supplier;
import com.starcraft.StarcraftMod;
import com.starcraft.ModMaterials;
import com.starcraft.registry.*;
import com.starcraft.item.*;
import com.starcraft.block.*;
import com.starcraft.block.entity.*;
import com.starcraft.menu.*;
import com.starcraft.client.screen.*;
import com.starcraft.entity.*;
import com.starcraft.entity.model.*;
import com.starcraft.client.*;
import com.starcraft.energy.ModEnergy;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.starcraft.entity.StarGuardianEntity;
import com.starcraft.StarcraftMod;

public class StarGuardianModel extends EntityModel<StarGuardianEntity> {

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
        new ResourceLocation(StarcraftMod.MODID, "star_guardian"), "main");

    private final ModelPart root;
    public final ModelPart head;
    public final ModelPart body;
    public final ModelPart armRight;
    public final ModelPart armLeft;
    public final ModelPart legRight;
    public final ModelPart legLeft;

    public StarGuardianModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.armRight = root.getChild("armRight");
        this.armLeft = root.getChild("armLeft");
        this.legRight = root.getChild("legRight");
        this.legLeft = root.getChild("legLeft");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create()
            .texOffs(0, 0)
            .addBox(0.0f, -8.0f, -4.0f, 8, 8, 8),
            PartPose.offset(-4.0f, 0.0f, 0.0f));
        root.addOrReplaceChild("body", CubeListBuilder.create()
            .texOffs(32, 0)
            .addBox(0.0f, 0.0f, -2.0f, 8, 12, 4),
            PartPose.offset(-4.0f, 0.0f, 0.0f));
        root.addOrReplaceChild("armRight", CubeListBuilder.create()
            .texOffs(0, 16)
            .addBox(0.0f, -2.0f, -2.0f, 4, 12, 4),
            PartPose.offset(-8.0f, 2.0f, 0.0f));
        root.addOrReplaceChild("armLeft", CubeListBuilder.create()
            .texOffs(16, 16)
            .addBox(0.0f, -2.0f, -2.0f, 4, 12, 4),
            PartPose.offset(4.0f, 2.0f, 0.0f));
        root.addOrReplaceChild("legRight", CubeListBuilder.create()
            .texOffs(32, 16)
            .addBox(0.0f, 0.0f, -2.0f, 4, 12, 4),
            PartPose.offset(-4.0f, 12.0f, 0.0f));
        root.addOrReplaceChild("legLeft", CubeListBuilder.create()
            .texOffs(48, 16)
            .addBox(0.0f, 0.0f, -2.0f, 4, 12, 4),
            PartPose.offset(0.0f, 12.0f, 0.0f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(StarGuardianEntity entity, float limbSwing, float limbSwingAmount,
            float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float)Math.PI / 180F);
        this.head.xRot = headPitch * ((float)Math.PI / 180F);
        this.legRight.xRot = (float)Math.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.legLeft.xRot = (float)Math.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.armRight.xRot = (float)Math.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.armLeft.xRot = (float)Math.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.body.y = (float)Math.sin(ageInTicks * 0.05F) * 0.05F;
        float kfT = (ageInTicks / 20.0f) % 2.0000f;
        this.armLeft.zRot = keyed(kfT, new float[]{0.0000f, 1.0000f, 2.0000f}, new float[]{-0.0698f, 0.1047f, -0.0698f});
        this.armRight.zRot = keyed(kfT, new float[]{0.0000f, 1.0000f, 2.0000f}, new float[]{0.0698f, -0.1047f, 0.0698f});
        this.head.yRot = keyed(kfT, new float[]{0.0000f, 1.0000f, 2.0000f}, new float[]{-0.0873f, 0.0873f, -0.0873f});
    }

    private static float keyed(float t, float[] times, float[] values) {
        if (times.length == 0) return 0.0f;
        if (t <= times[0]) return values[0];
        for (int i = 1; i < times.length; i++) {
            if (t <= times[i]) {
                float span = times[i] - times[i - 1];
                float k = span > 0.0f ? (t - times[i - 1]) / span : 0.0f;
                return values[i - 1] + (values[i] - values[i - 1]) * k;
            }
        }
        return values[values.length - 1];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
            int packedOverlay, float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
