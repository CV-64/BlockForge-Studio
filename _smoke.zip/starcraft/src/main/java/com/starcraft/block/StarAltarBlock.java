package com.starcraft.block;

import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.server.level.*;
import net.minecraft.commands.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.energy.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;
import net.minecraft.world.food.*;
import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.chat.*;
import net.minecraft.nbt.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.*;
import net.minecraft.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.*;
import java.util.function.Supplier;
import com.starcraft.StarcraftMod;
import com.starcraft.ModMaterials;
import com.starcraft.registry.*;
import com.starcraft.item.*;
import com.starcraft.block.*;
import com.starcraft.block.entity.*;
import com.starcraft.menu.*;
import com.starcraft.client.screen.*;
import com.starcraft.entity.*;
import com.starcraft.entity.model.*;
import com.starcraft.client.*;
import com.starcraft.energy.ModEnergy;

/* 多方块核心：按相对核心的偏移校验结构，成型后执行配置的动作。
   结构检测只在服务端进行，客户端右键仅作为反馈。 */
public class StarAltarBlock extends Block {

    private static final int[][] OFFSETS = new int[][]{
        new int[]{1, 0, 0},
        new int[]{-1, 0, 0},
        new int[]{0, 0, 1},
        new int[]{0, 0, -1},
        new int[]{0, 1, 0}
    };
    private static final Block[] STRUCT = new Block[]{
        ModBlocks.STAR_BLOCK.get(),
        ModBlocks.STAR_BLOCK.get(),
        ModBlocks.STAR_BLOCK.get(),
        ModBlocks.STAR_BLOCK.get(),
        ModBlocks.STAR_BLOCK.get()
    };

    public static final int COOLDOWN = 40;
    public static final int RADIUS = 8;

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    public StarAltarBlock() {
        super(BlockBehaviour.Properties.of().mapColor(DyeColor.GREEN).sound(SoundType.STONE).strength(1.5f, 6.0f));
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return this.defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    /** 结构是否完整：任一格的方块与配置不符即视为未成型 */
    public boolean isFormed(Level level, BlockPos pos) {
        if (OFFSETS.length == 0) return true;
        for (int i = 0; i < OFFSETS.length; i++) {
            BlockPos p = pos.offset(OFFSETS[i][0], OFFSETS[i][1], OFFSETS[i][2]);
            if (!level.getBlockState(p).is(STRUCT[i])) return false;
        }
        return true;
    }

    private void runActions(Level level, BlockPos pos) {
        if (!(level instanceof ServerLevel sl)) return;
        for (Player nearby : sl.getEntitiesOfClass(Player.class, new AABB(pos).inflate(RADIUS))) {
            nearby.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 0));
        }
        Block.popResource(sl, pos.offset(0, 1, 0), new ItemStack(ModItems.STAR_INGOT.get(), 2));
        {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
            if (bolt != null) {
                bolt.moveTo(pos.getX() + 0.5D + 0, pos.getY() + 2, pos.getZ() + 0.5D + 0);
                sl.addFreshEntity(bolt);
            }
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!isFormed(level, pos)) {
            player.displayClientMessage(Component.translatable("message.starcraft.star_altar.not_formed"), true);
            return InteractionResult.CONSUME;
        }
        if (player != null && COOLDOWN > 0) {
            if (player.getCooldowns().isOnCooldown(this.asItem())) return InteractionResult.CONSUME;
            player.getCooldowns().addCooldown(this.asItem(), COOLDOWN);
        }
        if (isFormed(level, pos)) runActions(level, pos);
        return InteractionResult.CONSUME;
    }

}
