# 新模组 — Minecraft 1.20.1 Forge 模组

> 本项目由 **BlockForge Studio** 可视化模组制作器生成，全部 Java 源码、材质、模型、配方与语言文件均可直接编辑。
> 本文件已包含完整的构建 / 安装 / GitHub 分享说明，照着做即可。

## 基本信息

| 项目 | 值 |
| --- | --- |
| 模组 ID | `newmod` |
| 包名 | `com.newmod` |
| Minecraft | 1.20.1 (Java Edition) |
| Forge | 47.3.0 |
| Java | 17 |
| 元素数量 | 13 |

## 创造模式物品栏与模组封面

- 本模组在创造模式背包中拥有**独立页签**：`新模组`，所有模组物品集中显示在这里。
- 页签图案：`assets/newmod/textures/item/creative_tab_icon.png`（16×16）；
  标题：`assets/newmod/lang/*.json` 里的 `itemGroup.newmod.main`。
  两者可在 BlockForge Studio「模组信息 → 创造模式物品栏」里直接绘制 / 修改。
- 模组封面图是 jar 根目录的 `pack.png`（64×64）。资源包选择界面与 Forge 模组列表
  （`META-INF/mods.toml` 的 `logoFile="pack.png"`）都会显示它；
  可在「模组信息 → 模组封面图」中绘制或上传图片后重新导出。

## 构建方法（照做即可）

**本工程已自带 Gradle Wrapper，不需要安装 Gradle。**

1. 安装 **JDK 17**（务必是 17，Forge 1.20.1 不兼容更高版本；你机器上若是 21 也可，见下方说明）。
   下载：<https://adoptium.net/temurin/releases/?version=17>
2. **Windows**：双击 `build.bat`（或在命令行执行 `build.bat`）。
   **Linux / macOS**：执行 `chmod +x build.sh && ./build.sh`。
   首次运行会自动下载 Gradle 与 Forge 依赖（5-20 分钟），之后会很快。
3. 构建产物位于 `build/libs/newmod-1.0.0.jar`。
4. 把该 jar 复制到 Minecraft 的 `mods` 文件夹：
   - Windows：`%APPDATA%\.minecraft\mods\`
   - Linux / macOS：`~/.minecraft/mods/`
5. 用 **Forge 1.20.1**（47.3.0）启动客户端，模组即生效。

### 手动命令（等价）

```bash
./gradlew build          # Windows: gradlew.bat build
./gradlew runClient      # 直接启动带本模组的开发客户端（推荐调试用）
./gradlew runServer      # 启动开发服务端
./gradlew runData        # 重新生成数据（模型 / 配方）
```

### 关于 JDK 版本

Forge 1.20.1 官方要求 **JDK 17**。本工程的处理方式：

- **本机已装 JDK 17** → 直接用它编译，最稳。
- **只有 JDK 21 等其它版本** → 也能编译：Gradle 会用当前 JDK 编译并输出 Java 17 字节码
  （`options.release = 17`），无需任何额外操作。
- **想完全对齐官方环境** → 装 Temurin 17：<https://adoptium.net/temurin/releases/?version=17>
  国内下载可用镜像：<https://mirrors.tuna.tsinghua.edu.cn/Adoptium/>

> `settings.gradle` 已配置 foojay 工具链插件：若需要自动下载 JDK 17 会自动处理，
> 但 GitHub 直连常被卡，**推荐手动装 Temurin 17**（或直接用上面的 JDK 21 兼容方案）。

## 分享到 GitHub

```bash
# 方式一：已安装 GitHub CLI（推荐）
gh repo create newmod-mod --public --source=. --remote=origin --push

# 方式二：网页建空仓库后
git init
git add .
git commit -m "Initial commit: 新模组 mod"
git branch -M main
git remote add origin https://github.com/<你的用户名>/newmod-mod.git
git push -u origin main
```

> `.gitignore` 已排除 `build/`、`.gradle/`、`run/`，不会被提交。
> 想把成品 jar 发给朋友，到仓库的 **Releases → New release** 上传 `build/libs/*.jar` 即可。

## 目录说明

```
src/main/java/com/newmod/
  NewmodMod.java                 主类：注册 DeferredRegister / 创造标签 / 可燃性
  ModMaterials.java            自定义工具材料(Tier) 与护甲材料(ArmorMaterial)
  registry/                   物品、方块、方块实体、菜单类型注册表
  item/                       每个元素一个物品类（提示文本、右键、命中特效、耐久等）
  block/                      方块类；工作站继承 BaseEntityBlock
  block/entity/               工作站方块实体：容器、NBT 持久化、配方处理逻辑
  menu/                       容器菜单：槽位布局与快速移动
  client/                     客户端屏幕注册与 GUI 渲染
src/main/resources/
  META-INF/mods.toml          模组元数据与依赖声明
  assets/newmod/               贴图 / 模型 / blockstate / 语言文件
  data/newmod/                 合成配方 / 战利品表 / 挖掘标签
    worldgen/                     configured_feature + placed_feature（原版矿物生成）
    forge/biome_modifier/         Forge add_features 生物群系注入
.modmaker/project.json        可重新导入 BlockForge Studio 继续编辑的工程源文件
```

## 关于工作站

工作站的配方逻辑写在对应 `block/entity/*BlockEntity.java` 的 `RECIPES` 常量中：
方块实体每游戏刻检查输入槽物品，达到 `WORK_TIME` 后消耗输入并在输出槽生成产物。
槽位坐标由编辑器 GUI 设计器生成，与 `menu/*Menu.java` 中的 `addSlot` 一一对应。
如需接入能量、流体或 JEI 兼容，可在此基础上扩展（Forge Capability 系统）。

## 六面贴图与放置朝向

- 方块贴图共 6 张：`top / bottom / front / back / left / right`，分别对应模型纹理键
  `up / down / north / south / west / east`，父模型为 `minecraft:block/cube`。
- 方块类声明 `BlockStateProperties.HORIZONTAL_FACING`，放置时取玩家水平朝向的反方向，
  `blockstates/*.json` 用 `y` 轴旋转 0/90/180/270 把 north 面转到对应方向。
- 物品图标为 `item/<注册名>.png`，模型使用 `item/generated`。
- 护甲穿戴贴图 `models/armor/<注册名>_layer_1/2.png` 由物品图标平铺生成，
  如需精细穿戴外观，可用 BlockBench 或像素编辑器替换这两张 64×32 贴图。
- GUI 背景由编辑器按槽位布局程序化绘制（256×256，前 176×166 为界面）；
  画板默认直接载入这份示例界面作为底稿，可在其上继续修改，「恢复为示例 UI」可重新取底稿。

## 物品模型与手持显示

- 工具 / 武器默认使用 `minecraft:item/handheld`，与原版剑、镐一致，
  包含正确的第一 / 第三人称握持变换；材料、食物、护甲、杂项使用 `minecraft:item/generated`。
  可在元素「基本信息 → 手持 / 图标模型」中手动指定 `auto / generated / handheld`。
- 所有带耐久的物品在 `Item.Properties` 中强制 `.stacksTo(1)`：
  可堆叠上限大于 1 同时又有耐久，会导致手持与耐久条显示异常。

## 矿物生成（参考原版 1.20.1 代码）

在编辑器「矿物生成」标签页启用后，工程会生成三个层次的数据包文件：

1. `worldgen/configured_feature/<注册名>_ore.json` — `minecraft:ore`，对应原版
   `OreFeature` / `OreConfiguration`：`size`（矿脉大小）、`targets`（`TagMatchTest` 的
   `stone_ore_replaceables` / `deepslate_ore_replaceables`，或 `BlockMatchTest`）与
   `discard_chance_on_air_exposure`（暴露空气时的丢弃概率）。
2. `worldgen/placed_feature/<注册名>_ore.json` — 对应 `PlacementUtils.inSquare`、
   `CountPlacement`、`HeightRangePlacement.uniform/trapezoid` 与 `BiomeFilter.biome()`。
3. `forge/biome_modifier/<注册名>_ore_<维度>.json` — `forge:add_features`，
   阶段 `underground_ores`，生物群系标签 `#minecraft:is_overworld` / `is_nether` / `is_end`。

## 工具属性与物品效果（参考原版覆写）

- `getDestroySpeed(ItemStack, BlockState)` — 对所选方块标签返回自定义挖掘速度。
- `canPerformAction(ItemStack, ToolAction)` — Forge `ToolActions`（剥皮、整平、耕地等）。
- `getAttributeModifiers(EquipmentSlot, ItemStack)` — 用 `ImmutableMultimap` 写入
  `Attributes.ATTACK_DAMAGE` / `ATTACK_SPEED`，对应原版 `SwordItem` 的实现。
- `isValidRepairItem`、`isEnchantable`、`isCorrectToolForDrops`、`hurtEnemy`、
  `inventoryTick`、`use`、`finishUsingItem`、`getUseAnimation`、`getBurnTime`
  均由编辑器选项按原版签名生成；护甲穿戴效果与火药味效果都走 `MobEffectInstance`。
- `Tier#getIncorrectBlocksForDrops()` 返回所选的 `minecraft:incorrect_for_*_tool` 标签。

## 合成配方与可合成开关

每个元素都有「可合成」开关：关闭时不生成 `data/<modid>/recipes/*.json`（例如只能靠
矿物生成获得的矿石），但仍可通过「是否出现在创造标签」单独控制创造模式可见性。

## 能量系统（Forge Energy, 单位 FE）

- **能量导管**：持有 `net.minecraftforge.energy.EnergyStorage`（容量 / 每刻传输量），
  每游戏刻通过 `ModEnergy.push()` 向六个方向推送能量。
- **产能方块**：同样暴露 `IEnergyStorage`，支持恒定产能、白天产能、燃料产能三种模式；
  燃料模式每个燃烧周期消耗容器中 1 个物品。
- **工作站**：`stationEnergy` 配置容量、最大输入 / 输出、每次配方消耗；
  方块实体 tick 中检查 `ENERGY_COST` 后才推进进度，完成时扣除能量。
  `ContainerData` 扩展为 4 槽（进度 / 总时长 / 当前能量 / 容量），客户端同步后由
  `Screen` 用 `GuiGraphics.fill` 绘制能量条，并在悬停时显示 `x / y FE`。
- 三者都覆写 `BlockEntity#getCapability(ForgeCapabilities.ENERGY, side)` 与
  `invalidateCaps()`，因此可与其它 Forge 能量模组互联互通。

## 晶簇方块（参考原版 AmethystClusterBlock）

- 六向 `BlockStateProperties.FACING`、十字 `minecraft:block/cross` 模型，
  `blockstates` 用 x/y 旋转把十字贴到六个面；`canSurvive()` 检查支撑方块，
  支撑消失时 `updateShape()` 自动变空气；`getShape()` 按方向返回碰撞箱。
- 世界生成为自定义 Java `Feature<NoneFeatureConfiguration>`：
  在空气位置检查六个相邻方块是否为指定支撑方块，若是则放置朝外的晶簇
  （对应原版紫水晶晶洞在母岩表面生成晶簇的逻辑）。
- 数据包链：`worldgen/configured_feature`（type 指向 Java 注册的 Feature）、
  `worldgen/placed_feature`（count / in_square / height_range / biome）、
  `forge/biome_modifier`（阶段 underground_decoration）。

## 可绘制的 GUI 背景

- 工作站「工作站界面」标签页内置 176×166 像素画板，可手绘背景、
  一键导入程序化布局作为底图、清空、随时切回自动布局。
- 手绘像素保存为元素字段 `guiPixels`，导出时覆盖 `textures/gui/*.png` 的
  前 176×166 区域；纹理右侧 `u >= 176` 的进度箭头与火焰图集始终保留，
  供 `Screen#renderBg` 通过 blit 绘制。槽位坐标仍以菜单 `addSlot` 为准，
  因此可以自由绘制槽位外观而不影响逻辑。

## 生物（刷怪蛋形式）

- 生物以**刷怪蛋**注册：物品 ID 为 `<注册名>_spawn_egg`，使用 `ForgeSpawnEggItem`，蛋贴图可自行绘制。
- `registry/ModEntities.java` 注册 `EntityType`；`entity/*Entity.java` 实现属性、AI 目标、攻击方式、
  技能、掉落、经验与交易；`entity/model/*Model.java` 是由部件表生成的 `ModelPart` 树；
  `client/*Renderer.java` 负责渲染器，并在 `ClientSetup` 中注册模型层与渲染器。
- 建模：每个部件是「枢轴 + 偏移 + 尺寸」的长方体，贴图按原版 box UV 规则排布
  （编辑器按同一规则自动生成 64×64 皮肤，保证与 `texOffs` 一致）。
- 动画：`setupAnim` 内置行走摆动与呼吸；关键帧动画另存为
  `assets/<modid>/animations/<注册名>.animation.json`（1.20.1 客户端格式）。
- 血条形式：普通血条 / 顶部 Boss 血条（原版 `ServerBossEvent` + `startSeenByPlayer`）/
  始终显示名称与血量。
- 交易：友好生物覆写 `getOffers()` 返回 `MerchantOffers`，不依赖版本相关的交易签名。

## 已适配的 1.20.1 API 差异（生成器已处理，无需手改）

- 方块属性用 `Properties.of()` + `.mapColor(DyeColor)`（1.20.1 已移除 `Material` 类）
- 模型用 `net.minecraft.client.model.geom.*` + `builders.*`，并实现 `renderToBuffer`
- 渲染器用 `ctx.bakeLayer(Model.LAYER)` 取模型
- 容器界面注册走 `FMLClientSetupEvent` + `MenuScreens.register`（Forge 47.3 无 `RegisterMenuScreensEvent`）
- 实体模型层与渲染器注册走 `EntityRenderersEvent.RegisterLayerDefinitions` / `RegisterRenderers`
- 爆炸用 `Level.ExplosionInteraction`（旧 `Explosion.BlockInteraction` 已移除）
- 经验用构造里的 `this.xpReward`，技能命中用 `doHurtTarget(Entity)`

> 本工程已用 Forge 1.20.1-47.3.0 实际执行 `gradlew build` 验证通过（BUILD SUCCESSFUL）。

生成时间：2026/11/7 14:26:32 · 共 157 个文件
