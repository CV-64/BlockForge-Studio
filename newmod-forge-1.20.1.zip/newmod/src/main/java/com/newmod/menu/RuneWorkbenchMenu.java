package com.newmod.menu;

import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.server.level.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.energy.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;
import net.minecraft.world.food.*;
import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.chat.*;
import net.minecraft.nbt.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.*;
import net.minecraft.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.*;
import java.util.function.Supplier;
import com.newmod.NewmodMod;
import com.newmod.ModMaterials;
import com.newmod.registry.*;
import com.newmod.item.*;
import com.newmod.block.*;
import com.newmod.block.entity.*;
import com.newmod.menu.*;
import com.newmod.client.screen.*;
import com.newmod.entity.*;
import com.newmod.entity.model.*;
import com.newmod.client.*;
import com.newmod.energy.ModEnergy;

public class RuneWorkbenchMenu extends AbstractContainerMenu {

    private final SimpleContainer container;
    private final ContainerData data;
    private final Level level;
    private final BlockPos pos;

    public RuneWorkbenchMenu(int id, Inventory inv, BlockPos pos, ContainerData data) {
        super(ModMenuTypes.RUNE_WORKBENCH.get(), id);
        this.level = inv.player.level();
        this.pos = pos;
        this.data = data;
        BlockEntity be = level.getBlockEntity(pos);
        this.container = be instanceof RuneWorkbenchBlockEntity station ? station.getContainer() : new SimpleContainer(4);
        addDataSlots(data);

        addSlot(new Slot(container, 0, 32, 26));
        addSlot(new Slot(container, 1, 56, 26));
        addSlot(new Slot(container, 2, 112, 34) {
            @Override public boolean mayPlace(ItemStack stack) { return false; }
            @Override public boolean mayPickup(Player player) { return true; }
        });
        addSlot(new Slot(container, 3, 44, 64));

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inv, 9 + row * 9 + col, 9 + col * 18, 85 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inv, col, 9 + col * 18, 143));
        }
    }

    public int getScaledProgress() {
        int p = data.get(0), max = data.get(1);
        return (max <= 0 || p <= 0) ? 0 : p * 24 / max;
    }
    public boolean isCrafting() { return data.get(0) > 0; }
    public int getEnergyStored() { return data.getCount() > 2 ? data.get(2) : 0; }
    public int getEnergyCapacity() { return data.getCount() > 2 ? data.get(3) : 0; }
    public int getEnergyScaled() {
        int cap = getEnergyCapacity();
        return cap <= 0 ? 0 : getEnergyStored() * 54 / cap;
    }

    @Override public boolean stillValid(Player player) {
        return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
    }

    @Override public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = getSlot(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack original = slot.getItem().copy(), result = slot.getItem().copy();
        if (index < 4) {
            if (!moveItemStackTo(result, 4, 36 + 4, true)) return ItemStack.EMPTY;
        } else {
            if (!moveItemStackTo(result, 0, 2, false)) return ItemStack.EMPTY;
        }
        if (result.isEmpty()) slot.set(ItemStack.EMPTY); else slot.set(result);
        slot.setChanged();
        return original;
    }
}
