package com.newmod.block.entity;

import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.server.level.*;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.item.context.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.energy.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;
import net.minecraft.world.food.*;
import net.minecraft.world.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.phys.*;
import net.minecraft.network.chat.*;
import net.minecraft.nbt.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.*;
import net.minecraft.*;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.*;
import java.util.function.Supplier;
import com.newmod.NewmodMod;
import com.newmod.ModMaterials;
import com.newmod.registry.*;
import com.newmod.item.*;
import com.newmod.block.*;
import com.newmod.block.entity.*;
import com.newmod.menu.*;
import com.newmod.client.screen.*;
import com.newmod.entity.*;
import com.newmod.entity.model.*;
import com.newmod.client.*;
import com.newmod.energy.ModEnergy;

public class RuneWorkbenchBlockEntity extends BlockEntity implements MenuProvider {

    public static final int SLOT_COUNT = 4;
    public static final int INPUT_SLOTS = 2;
    public static final int OUTPUT_SLOT = 2;
    public static final int WORK_TIME = 120;
    public static final int ENERGY_COST = 120;

    public static final List<StationRecipe> RECIPES = List.of(
        new StationRecipe(new ItemStack(Items.IRON_INGOT), 1, new ItemStack(Items.REDSTONE), 1, new ItemStack(ModItems.STAR_INGOT.get()), 1)
    );

    private final SimpleContainer container = new SimpleContainer(SLOT_COUNT) {
        @Override public void setChanged() { RuneWorkbenchBlockEntity.this.setChanged(); }
    };
    private int progress = 0;
    public final EnergyStorage energy = new EnergyStorage(10000, 256, 64);
    private final LazyOptional<IEnergyStorage> holder = LazyOptional.of(() -> energy);
    public final ContainerData data = new ContainerData() {
        @Override public int get(int i) {
            if (i == 0) return progress;
            if (i == 1) return WORK_TIME;
            if (i == 2) return energy.getEnergyStored();
            if (i == 3) return energy.getMaxEnergyStored();
            return 0;
        }
        @Override public void set(int i, int v) { if (i == 0) progress = v; }
        @Override public int getCount() { return 4; }
    };

    public RuneWorkbenchBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.RUNE_WORKBENCH.get(), pos, state);
    }

    public SimpleContainer getContainer() { return container; }
    public ContainerData getData() { return data; }

    public static void tick(Level level, BlockPos pos, BlockState state, RuneWorkbenchBlockEntity be) {
        if (level.isClientSide) return;
        StationRecipe recipe = be.findRecipe();
        boolean canWork = recipe != null && be.container.getItem(OUTPUT_SLOT).isEmpty() && !be.container.getItem(3).isEmpty() && be.energy.getEnergyStored() >= ENERGY_COST;
        if (canWork) {
            be.progress++;
            if (be.progress >= WORK_TIME) {
                be.container.setItem(OUTPUT_SLOT, recipe.out.copy());
                recipe.consume(be.container);
            be.container.removeItem(3, 1);
            be.energy.extractEnergy(ENERGY_COST, false);
                be.progress = 0;
            }
        } else { be.progress = 0; }
        be.setChanged();
    }

    private StationRecipe findRecipe() {
        for (StationRecipe r : RECIPES) if (r.matches(container)) return r;
        return null;
    }

    @Override public Component getDisplayName() {
        return Component.translatable("container.newmod.rune_workbench");
    }

    @Override public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new RuneWorkbenchMenu(id, inv, getBlockPos(), data);
    }

    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ListTag items = new ListTag();
        for (int i = 0; i < container.getContainerSize(); i++) {
            if (!container.getItem(i).isEmpty()) {
                CompoundTag entry = new CompoundTag();
                entry.putByte("Slot", (byte) i);
                container.getItem(i).save(entry);
                items.add(entry);
            }
        }
        tag.put("Items", items);
        tag.putInt("Progress", progress);
        tag.putInt("Energy", energy.getEnergyStored());
    }

    @Override public void load(CompoundTag tag) {
        super.load(tag);
        ListTag items = tag.getList("Items", 10);
        for (int i = 0; i < items.size(); i++) {
            CompoundTag entry = items.getCompound(i);
            int slot = entry.getByte("Slot") & 255;
            if (slot < container.getContainerSize()) container.setItem(slot, ItemStack.of(entry));
        }
        progress = tag.getInt("Progress");
        int stored = tag.getInt("Energy");
        energy.extractEnergy(energy.getEnergyStored(), false);
        while (stored > 0) { int a = energy.receiveEnergy(stored, false); if (a <= 0) break; stored -= a; }
    }

    @Override public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
        return cap == ForgeCapabilities.ENERGY ? holder.cast() : super.getCapability(cap, side);
    }

    @Override public void invalidateCaps() { super.invalidateCaps(); holder.invalidate(); }

    public static class StationRecipe {
        public final ItemStack a, b, out;
        public final int ca, cb;
        public StationRecipe(ItemStack a, int ca, ItemStack b, int cb, ItemStack out, int count) {
            this.a = a; this.ca = ca; this.b = b; this.cb = cb;
            this.out = out.copy(); this.out.setCount(count);
        }
        public boolean matches(SimpleContainer c) {
            boolean okA = a.isEmpty() || (INPUT_SLOTS > 0 && c.getItem(0).is(a.getItem()) && c.getItem(0).getCount() >= ca);
            boolean okB = b.isEmpty() || (INPUT_SLOTS > 1 && c.getItem(1).is(b.getItem()) && c.getItem(1).getCount() >= cb);
            return (okA && okB) && (!a.isEmpty() || !b.isEmpty());
        }
        public void consume(SimpleContainer c) {
            if (!a.isEmpty() && INPUT_SLOTS > 0) c.removeItem(0, ca);
            if (!b.isEmpty() && INPUT_SLOTS > 1) c.removeItem(1, cb);
        }
    }
}
